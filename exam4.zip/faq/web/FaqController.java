/**
 * 
 */
package egovframework.example.faq.web;

/**
 * @author user
 *
 */
public class FaqController {

}
