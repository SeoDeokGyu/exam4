/**
 * 
 */
package egovframework.example.exam4;

/**
 * @author user
 *
 */
public class A {
//		1. 스프링 MVC 디자인 패턴에 대해서 설명해주세요
//		M : model -> 비즈니스 로직 데이터 처리 담당 예를 들어 서비스, VO 등이 있다
//		V : view -> 우리한테 보여지는 화면 담당이다 예를 들어 JSP가 있다
//		C : controller -> 요청하는걸 처리한다 서비스를 호출해서 결과를 jsp 에 전달
//	
//	
}
